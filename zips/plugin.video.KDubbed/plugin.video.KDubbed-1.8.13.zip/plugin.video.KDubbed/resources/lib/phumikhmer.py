# ────────────────────────────────────────────────
#  PHUMIKHMER2 SITE HANDLER
# ────────────────────────────────────────────────
import re, sys, json, xbmc, xbmcplugin, xbmcgui
from urllib.parse import urljoin, quote_plus, unquote_plus, urlparse, urlunparse, quote, unquote
from bs4 import BeautifulSoup

# ── Local Handlers ──────────────────────────────
from resources.lib.handlers_khmer import (
    OpenSoup as OpenSoup_KH,
    OpenURL as OpenURL_KH,
)

from resources.lib.handlers_common import USER_AGENT 
from resources.lib.handlers_blogid import (
    ADDON_ID,
    extract_all_blogger_json_urls_from_page,
    parse_blogger_video_links,
)
try:
    ADDON_ID
except NameError:
    ADDON_ID = "plugin.video.KDubbed"

# ── Plugin Handle ───────────────────────────────
PHUMIK       = 'https://www.phumikhmer1.club/'
PLUGIN_HANDLE = int(sys.argv[1])

############## phumikhmer2 ****************** 
def INDEX_PHUMIK(url):
    _render_phumik_listing(url, label_suffix=None, include_pagination=True)

def SINDEX_PHUMIK(url, end_directory=True):  # for search
    _render_phumik_listing(
        url,
        label_suffix=" [COLOR green]PhumiKhmer[/COLOR]",
        include_pagination=False,
        end_directory=end_directory
    )

def _render_phumik_listing(url, label_suffix=None, include_pagination=True, end_directory=True):
    soup, html = OpenSoup_KH(url, return_html=True)

    if soup is None:
        xbmc.log(f"[{ADDON_ID}] PhumiClub catalog: no HTML parsed for {url}", xbmc.LOGWARNING)
        if end_directory:
            xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    posts = soup.select("div.blog-posts div.grid-posts article.blog-post")
    xbmc.log(f"[{ADDON_ID}] PhumiClub catalog: {len(posts)} post containers at {url}", xbmc.LOGINFO)
    shown = 0
    seen = set()
    for post in posts:
        a_tag = post.select_one("div.post-filter-image a.post-filter-link") or post.select_one("h2.entry-title a")
        h2_tag = post.select_one("h2.entry-title")
        img_tag = post.select_one("img.snip-thumbnail")
        if not a_tag:
            continue

        title_text = ((a_tag.get("title") or "").strip() or
                      (h2_tag.get_text(" ", strip=True) if h2_tag else "") or
                      a_tag.get_text(" ", strip=True)).strip()
        v_link = urljoin(url, (a_tag.get("href") or "").strip())
        if not title_text or not v_link or v_link in seen:
            continue

        post_tag = post.select_one("span.post-tag-fly")
        label_tag = post.select_one("span.label-news-flex")
        post_tag_text = post_tag.get_text(" ", strip=True).lower() if post_tag else ""
        label_text = label_tag.get_text(" ", strip=True).lower() if label_tag else ""
        title_lower = title_text.lower()
        href = v_link.lower()
        if (post_tag_text == "actors" or label_text == "actors" or
            "/search/label/actors" in href or "biography, career" in title_lower or
            "popular chinese drama roles" in title_lower or "rising star" in title_lower):
            continue

        v_image = ((img_tag.get("data-src") or img_tag.get("src") or "") if img_tag else "")
        if not v_image:
            nested = a_tag.select_one("img")
            if nested:
                v_image = nested.get("data-src") or nested.get("src") or ""
        v_image = urljoin(url, v_image) if v_image else ""
        v_image = re.sub(r"/w\d+-h\d+[^/]*/", "/s1600/", v_image)
        v_image = clean_image_url(v_image)
        seen.add(v_link)
        shown += 1
        label = f"{title_text}{label_suffix}" if label_suffix else title_text
        addDir(label, v_link, "episode_phumik", v_image)

    xbmc.log(f"[{ADDON_ID}] PhumiClub catalog: displayed {shown} items", xbmc.LOGINFO)

    if include_pagination:
        next_page = ""

        # page 1 style
        load_more = soup.select_one("#blog-pager-ok a.load-more")
        if load_more:
            next_page = (load_more.get("href") or "").strip()

        # page 2+ style
        if not next_page:
            older_link = soup.select_one("#blog-pager a.blog-pager-older-link")
            if older_link:
                next_page = (older_link.get("href") or "").strip()

        # generic fallback
        if not next_page:
            for a in soup.find_all("a", href=True):
                href = (a.get("href") or "").strip()
                cls = " ".join(a.get("class", [])) if a.get("class") else ""
                if (
                    "updated-max=" in href and
                    ("blog-pager-older-link" in cls or "load-more" in cls)
                ):
                    next_page = href
                    break

        # raw html fallback
        if not next_page:
            m = re.search(
                r'<a[^>]+class=[\'"][^\'"]*(?:blog-pager-older-link|load-more)[^\'"]*[\'"][^>]+href=[\'"]([^\'"]+)[\'"]',
                html,
                re.I
            )
            if m:
                next_page = m.group(1).strip()

        if next_page:
            next_page = next_page.replace("&amp;", "&")
            addDir("NEXT PAGE", next_page, "index_phumik", "")

    if end_directory:
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
 
def EPISODE_PHUMIK(url, v_image=""):
    xbmc.log(f"[KDUBBED] EPISODE_PHUMIK received v_image={v_image}", xbmc.LOGINFO)

    html = OpenURL_KH(url, as_text=True)
    if not html:
        xbmc.log(f"[{ADDON_ID}] Failed to fetch PhumiKhmer page: {url}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error", "Could not load this PhumiKhmer episode page.")
        return

    v_image = clean_image_url(v_image)
    xbmc.log(f"[KDUBBED] PHUMIK CLEANED EPISODE IMAGE: {v_image}", xbmc.LOGINFO)

    blogger_urls = extract_all_blogger_json_urls_from_page(html) or []
    all_links, seen = [], set()
    ep_counter = 1

    for blogger_url in blogger_urls:
        xbmc.log(f"[{ADDON_ID}] PhumiKhmer Blogger URL: {blogger_url}", xbmc.LOGINFO)
        links = parse_blogger_video_links(blogger_url) or []
        for link in links:
            vurl = (link.get("file") or "").strip()
            if not vurl or vurl in seen:
                continue
            seen.add(vurl)
            all_links.append({'file': vurl, 'title': f"Episode {ep_counter:02d}"})
            ep_counter += 1

    if all_links:
        DIRECT_EXT = (".mp4", ".m3u8", ".aaa.mp4", ".gaa.mp4", ".caa.mp4")
        for item in all_links:
            vurl, vtitle = item['file'], item['title']
            if any(h in vurl for h in ("ok.ru", "youtube.com", "youtu.be", "vimeo.com")):
                addLink(vtitle, vurl, "video_hosting", v_image)
            elif any(vurl.split("?", 1)[0].endswith(ext) for ext in DIRECT_EXT):
                addLink(vtitle, vurl, "play_direct", v_image)
            else:
                addLink(vtitle, vurl, "video_hosting", v_image)
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    xbmc.log(f"[{ADDON_ID}] No Blogger feeds on PhumiKhmer page, trying fallback parse", xbmc.LOGINFO)

    m = re.search(r"options\.player_list\s*=\s*(\[[\s\S]+?\]);", html) \
        or re.search(r"const\s+videos\s*=\s*(\[[\s\S]+?\]);", html)

    if m:
        try:
            raw = m.group(1)
            raw = re.sub(r",\s*([\]}])", r"\1", raw)
            raw = re.sub(r'([{\s,])(\w+)\s*:', r'\1"\2":', raw)
            raw = raw.replace("'", '"')
            videos = json.loads(raw)
        except Exception as e:
            xbmc.log(f"[{ADDON_ID}] JSON parse failed on PhumiKhmer page: {e}", xbmc.LOGERROR)
            videos = []
    else:
        videos = []

    if videos:
        for idx, v in enumerate(videos, start=1):
            vurl = (v.get("file") or "").strip()
            if not vurl:
                continue
            vtitle = f"Episode {idx:02d}"
            if any(h in vurl for h in ("ok.ru", "youtube.com", "youtu.be", "vimeo.com")):
                addLink(vtitle, vurl, "video_hosting", v_image)
            else:
                addLink(vtitle, vurl, "play_direct", v_image)
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    xbmcgui.Dialog().ok("No Episodes Found", "Sorry, no playable episodes were detected on this PhumiKhmer page.")
    xbmc.log(f"[{ADDON_ID}] PhumiKhmer: no episode links found at {url}", xbmc.LOGWARNING)
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

# ── clean_image_url() ────────────────────
def clean_image_url(img_url):
    if not img_url:
        return ""

    img_url = img_url.strip()

    if re.search(r"^https?://i\d\.wp\.com/blogger\.googleusercontent\.com/", img_url):
        img_url = re.sub(r"^https?://i\d\.wp\.com/", "https://", img_url)

    img_url = img_url.split("?", 1)[0]

    parsed = urlparse(img_url)
    safe_path = quote(unquote(parsed.path), safe="/:._-()")
    return urlunparse((parsed.scheme, parsed.netloc, safe_path, "", "", ""))

# ── Shared playback handlers ────────────────────
from resources.lib.handlers_playback import (
    resolve_redirect,
    VIDEOLINKS,
    enable_inputstream_adaptive,
    Playloop,
    VIDEO_HOSTING,
    Play_VIDEO,
) 

# ────────────────────────────────────────────────
#  BASIC DIRECTORY HELPERS
# ────────────────────────────────────────────────
def addDir(name, url, action, iconimage=""):
    li = xbmcgui.ListItem(label=name)
    li.setArt({
        'thumb': iconimage,
        'icon': iconimage,
        'poster': iconimage,
        'landscape': iconimage,
        'fanart': iconimage,
        'banner': iconimage,
    })
    if iconimage:
        li.setProperty("Fanart_Image", iconimage)

    li.setInfo('video', {'title': name})

    u = (
        f"{sys.argv[0]}?"
        f"url={quote_plus(str(url))}"
        f"&action={quote_plus(str(action))}"
        f"&name={quote_plus(str(name))}"
        f"&icon={quote_plus(str(iconimage))}"
    )
    xbmcplugin.addDirectoryItem(handle=PLUGIN_HANDLE, url=u, listitem=li, isFolder=True)

def addLink(name, url, action, iconimage=""):
    li = xbmcgui.ListItem(label=name)
    li.setArt({
        'thumb': iconimage,
        'icon': iconimage,
        'poster': iconimage,
        'landscape': iconimage,
        'fanart': iconimage,
        'banner': iconimage,
    })
    if iconimage:
        li.setProperty("Fanart_Image", iconimage)

    li.setProperty("IsPlayable", "true")
    li.setInfo('video', {'title': name})

    u = (
        f"{sys.argv[0]}?"
        f"url={quote_plus(str(url))}"
        f"&action={quote_plus(str(action))}"
        f"&name={quote_plus(str(name))}"
        f"&icon={quote_plus(str(iconimage))}"
    )
    xbmcplugin.addDirectoryItem(handle=PLUGIN_HANDLE, url=u, listitem=li, isFolder=False)